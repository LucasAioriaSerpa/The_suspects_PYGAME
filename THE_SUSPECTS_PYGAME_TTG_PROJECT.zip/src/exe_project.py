#imports
from os import system as sys
import SCRIPTS.main as _m
if __name__ == "__main__":
    sys("cls") # clear terminal
    _m.Game().run()